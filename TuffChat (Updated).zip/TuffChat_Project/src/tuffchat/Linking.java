package tuffchat;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Linking {
    
    public Connection conn;
    public ResultSet res;
    public Statement stmt;
   
    public Linking(){
        systemConnection();
    }
    
    public void systemConnection(){

         try{
            Class.forName("com.mysql.jdbc.Driver");
            conn = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/school", "root", "");
            stmt = (Statement)conn.createStatement();
            //JOptionPane.showMessageDialog(null, "Cool");
            System.out.println("Connection successful!....");
         }
         catch(Exception e){
             //JOptionPane.showMessageDialog(null, "Not Cool");
             System.out.println("Connection unsuccessful....");
         }
     }

    
}