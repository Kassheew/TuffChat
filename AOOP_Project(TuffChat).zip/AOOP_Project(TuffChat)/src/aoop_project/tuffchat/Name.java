/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aoop_project.tuffchat;

/**
 *
 * @author Forte
 */
public class Name {
    private String firstName;
    private String lastName;
    
    //Default Constructor
    public Name(){}
    
    //Primary Constructor
    public Name(String firstName, String lastName){
        this.firstName=firstName;
        this.lastName=lastName;
    }
    
    //Accessor
    String GetFirstName(){
        return this.firstName;
    }
    
    String GetLastName(){
        return this.lastName;
    }
    
    //Mutators
    void SetFirstName(String firstName){
        this.firstName=firstName;
    }
    
    void SetLastName(String lastName){
        this.lastName=lastName;
    }
}
